# Chinese-novel-generation

基于Tensorflow 1.0.0，尝试使用中文文本训练RNN来产生中文小说。

博客地址: http://blog.csdn.net/heisejiuhuche/article/details/73010638
